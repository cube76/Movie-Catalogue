package com.apps.moviecatalogue.vo;

public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}
