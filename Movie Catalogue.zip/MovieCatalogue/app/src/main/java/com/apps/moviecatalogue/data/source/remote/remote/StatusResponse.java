package com.apps.moviecatalogue.data.source.remote.remote;

public enum StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}
