package com.apps.moviecatalogue.ui.bookmark;

import com.apps.moviecatalogue.data.source.local.entity.MovieEntity;

interface BookmarkFragmentCallback {
    void onShareClick(MovieEntity course);
}

